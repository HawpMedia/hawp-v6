<?php
/**
 * Displays the header mobile menu buttons.
 */
?>

<nav class="menu-buttons">
	<a class="menu-button menu-open js-turnon" href="#menu" data-target="#menu">
		<div class="menu-button-bar"></div>
	</a>
</nav>
